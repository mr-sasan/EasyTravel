const SERVER_URL = "http://192.168.154.1/EasyTravel/"; //"http://10.0.3.2/EasyTravel/"
export { SERVER_URL };